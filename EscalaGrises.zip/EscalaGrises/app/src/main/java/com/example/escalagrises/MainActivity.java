package com.example.escalagrises;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView=findViewById(R.id.imageView);
    }
    public static Bitmap imgToGrayscale(Bitmap img){
        Bitmap newImage = Bitmap.createBitmap(img.getWidth(),img.getHeight(),img.getConfig());

        int a,r,g,b;
        int colorPixel;
        int width=img.getWidth();
        int height=img.getHeight();

        for (int x=0; x<width;x++){
            for (int y=0; y<height;y++){
                colorPixel=img.getPixel(x,y);
                a= Color.alpha(colorPixel);
                r= Color.red(colorPixel);
                g= Color.green(colorPixel);
                b= Color.blue(colorPixel);
                r=(r+g+b)/3;
                g=r;
                b=r;
                newImage.setPixel(x,y,Color.argb(a,r,g,b));
            }
        }
        return newImage;
    }
}
