






%cliente(nombre, ciudad, calificacion-credito).

cliente(claudia, nochistlan, 5).
cliente(deysi, jerez, 4).
cliente(luis, jerez, 2).
cliente(luis_gerardo, ermita_guadalupe, 3).
cliente(gerardo, jerez, 4).
cliente(david, zacatecas, 2).

%articulos(clave, descripcion, limite_existencia).
articulos(a1, computadora, 15).
articulos(a2, raton_alambrico, 10).
articulos(a3, proyector, 10).
articulos(a4, adaptador_vga, 10).
articulos(a5, raton_inalambrico, 5).
articulos(a6, memoria_usb, 5).
articulos(a7, disco_externo, 5).
%articulos(Clave,Descripcion,5).
%articulos(Clave,Descripcion,_). con el guin bajo es para mostrar todos los elemnetos que tengan 3 datos
%en este caso no importa el tercer elemnto y no se mostrara con _

%inventario(clave, existencias).
inventario(a1, 32).
inventario(a2, 4).
inventario(a3, 5).
inventario(a4, 64).
inventario(a5, 12).
inventario(a6, 10).
inventario(a7, 89).


%crear una regla que muestre a los clientes de jerez
clientes_jerez(Nombre, Lugar) :- cliente(Nombre, jerez, _).

%mostrar lo clientes con calificacion de 5
clientes_calificacion(N, L, C) :- cliente(N,L,5).


%mostrar un listado con el nombre del producto  y su existencia